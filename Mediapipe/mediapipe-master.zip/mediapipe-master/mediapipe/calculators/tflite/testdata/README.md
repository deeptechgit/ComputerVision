The model files add.bin, add_quantized.bin
(and corresponding metatada json files) come from tensorflow/lite/testdata/
